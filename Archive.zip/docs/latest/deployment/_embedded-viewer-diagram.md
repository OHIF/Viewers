<div style="text-align: center;">
  <img src="/assets/img/embedded-viewer-diagram.png" alt="Embedded Viewer Diagram" style="margin: 0 auto;" />
  <div><i>embedded viewer diagram</i></div>
</div>
