<div style="text-align: center;">
  <img src="/assets/img/user-access-control-request-flow.png" alt="request flow example" style="margin: 0 auto;" />
  <div><i>simplified request flow diagram</i></div>
</div>
