# Quick Start

This page details how to get an instance of the OHIF Viewer up and running as
fast as possible. It shows how to grab a pre-built version of the application,
point it at your data source (PACS), and plop it on a web server.

## Options

### 1. Pre-built PWA

...

### 2. Script-Tag

...

### 3. Docker

...

## Security Concerns

- Secure your data

## Common Issues

- Missing server rewrite rules
- CORS issues when requesting data from PACS
