# DICOM Web

[DICOMWeb](https://en.wikipedia.org/wiki/DICOMweb) refers to RESTful DICOM Services and is a recently standardized set of guidelines for exchanging medical images and imaging metadata over the internet. Not all archives fully support it yet, but it is gaining wider adoption.
