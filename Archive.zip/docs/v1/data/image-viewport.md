# Image Viewport

### Main Viewport Component

The [imageViewerViewport](https://github.com/OHIF/Viewers/tree/master/Packages/ohif-viewerbase/client/components/viewer/imageViewerViewport) component
