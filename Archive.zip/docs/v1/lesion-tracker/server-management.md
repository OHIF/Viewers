# Lesion Tracker - Server Management

LesionTracker supports configuration of multiple servers and allows to switch between them. To configure the servers, click **Server Information** on the Configuration Menu.

![Server Information](../assets/img/LesionTracker/LT_Server_Info.png)
