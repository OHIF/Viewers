# Lesion Tracker - Audit Trail

1. To view Audit Trails, select **View Audit Log** on the Configuration menu.
2. To filter audit logs for a column or multiple columns, type or select in the
   related column or columns.

![Audit Trails](../assets/img/LesionTracker/LT_Audit_Trails.png)
