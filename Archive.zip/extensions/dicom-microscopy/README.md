# @ohif/extension-dicom-microscopy

![npm (scoped)](https://img.shields.io/npm/v/@ohif/extension-dicom-microscopy.svg?style=flat-square)

<!-- TODO: Simple image or GIF? -->

#### Index

Extension Id: `microscopy`

- [SopClassHandler Module](#sopclasshandler-module)
- [Viewport Module](#viewport-module)

## SopClassHandler Module

..

## Viewport Module

...

## Resources

### Repositories

...

<!--
  Links
  -->

<!-- prettier-ignore-start -->

<!-- prettier-ignore-end -->
