// /data/archive/projects/ITCRdemo/subjects/XNAT_JPETTS_S00011/experiments?format=json

export const ITCRdemo_XNAT_JPETTS_S00011_experiments = `{
  "ResultSet": {
    "Result": [
      {
        "date": "2011-11-17",
        "xsiType": "xnat:mrSessionData",
        "xnat:subjectassessordata/id": "XNAT_JPETTS_E00014",
        "insert_date": "2018-05-14 15:17:57.815",
        "project": "ITCRdemo",
        "ID": "XNAT_JPETTS_E00014",
        "label": "Patient2",
        "URI": "/data/experiments/XNAT_JPETTS_E00014"
      }
    ],
    "totalRecords": "1"
  }
}`;
