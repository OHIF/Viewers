export const getToggledPixels = arr => {
  return arr.map(item => {
    return 1;
  });
};
