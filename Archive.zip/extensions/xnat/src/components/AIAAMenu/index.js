import ConnectedAIAAMenu from './ConnectedAIAAMenu.js';

export {
  ConnectedAIAAMenu,
};