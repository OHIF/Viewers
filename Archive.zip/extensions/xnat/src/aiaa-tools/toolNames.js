const TOOL_NAMES = {
  AIAA_PROB_TOOL: 'AIAAProbeTool',
  /* Sub-types */
  // type: {
  //   DEEPGROW_TYPE: 'DeepgrowProbeTool',
  //   DEXTR3D_TYPE: 'DExtr3DProbeTool',
  // },
};

export default TOOL_NAMES;
