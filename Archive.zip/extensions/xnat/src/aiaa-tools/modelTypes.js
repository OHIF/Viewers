const Model_Types = {
  ANNOTATION: 'annotation',
  DEEPGROW: 'deepgrow',
  SEGMENTATION: 'segmentation',
};

export default Model_Types;
