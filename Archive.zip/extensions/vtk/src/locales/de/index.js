import Buttons from './Buttons.json';

export default {
  de: {
    Buttons,
  },
};
