const state = { mailTo: undefined, debugModalMessage: undefined };

export default state;
