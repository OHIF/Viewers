const TOOL_NAMES = {
  DICOM_SEG_TEMP_CROSSHAIRS_TOOL: 'DICOMSegTempCrosshairsTool',
};

export default TOOL_NAMES;
