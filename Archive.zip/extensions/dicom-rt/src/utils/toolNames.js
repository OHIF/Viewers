const TOOL_NAMES = {
  RTSTRUCT_DISPLAY_TOOL: 'RTStructDisplayTool',
};

export default TOOL_NAMES;
