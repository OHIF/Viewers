# @ohif/extension-lesion-tracker

This project is an OHIF extension that can be used with the Core OHIF Platform,
either at runtime, or as an ES6 dependency, to create a medical image viewing
application similar to that of the [legacy Lesion
Tracker][legacy-lesion-tracker] viewer.

## About

...

## Scope

...

### Configuration

...

### Extensions

...

## Build & Deploy

...

## Funding/Support

...

<!--
  LINKS
  -->

<!-- prettier-ignore-start -->
[legacy-lesion-tracker]: http://lesiontracker.ohif.org/studylist
<!-- prettier-ignore-end -->
