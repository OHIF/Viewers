module.exports = require("../../postcss.config.js");
