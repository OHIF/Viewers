import cornerstone from 'cornerstone-core';

const refreshViewports = () => {
  cornerstone.getEnabledElements().forEach(enabledElement => {
    if (enabledElement.image) {
      cornerstone.updateImage(enabledElement.element);
    }
  });
};

export default refreshViewports;
