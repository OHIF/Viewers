// /data/archive/projects/ITCRdemo/subjects/XNAT_JPETTS_S00012/experiments?format=json

export const ITCRdemo_XNAT_JPETTS_S00012_experiments = `{
  "ResultSet": {
    "Result": [
      {
        "date": "2014-08-11",
        "xsiType": "xnat:mrSessionData",
        "xnat:subjectassessordata/id": "XNAT_JPETTS_E00015",
        "insert_date": "2018-05-14 15:25:07.609",
        "project": "ITCRdemo",
        "ID": "XNAT_JPETTS_E00015",
        "label": "Patient1",
        "URI": "/data/experiments/XNAT_JPETTS_E00015"
      }
    ],
    "totalRecords": "1"
  }
}`;
