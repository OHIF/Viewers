// /data/archive/projects/?format=json

export const projects = `{
  "ResultSet": {
    "Result": [
      {
        "pi_firstname": "",
        "secondary_ID": "ITCRdemo",
        "pi_lastname": "",
        "name": "ITCRdemo",
        "description": "",
        "ID": "ITCRdemo",
        "URI": "/data/projects/ITCRdemo"
      },
      {
        "pi_firstname": "",
        "secondary_ID": "Test_Viewer",
        "pi_lastname": "",
        "name": "Test_Viewer",
        "description": "Test project for viewer intergration",
        "ID": "TEST_Viewer",
        "URI": "/data/projects/TEST_Viewer"
      }
    ],
    "totalRecords": "2"
  }
}`;
