// /data/archive/projects/TEST_Viewer/subjects?format=json

export const TESTViewer_subjects = `{
  "ResultSet": {
    "Result": [
      {
        "insert_date": "2019-03-05 16:46:37.103",
        "project": "TEST_Viewer",
        "ID": "XNAT_JPETTS_S00032",
        "label": "QIN-HEADNECK-01-0003",
        "insert_user": "admin",
        "URI": "/data/subjects/XNAT_JPETTS_S00032"
      }
    ],
    "totalRecords": "1"
  }
}`;
